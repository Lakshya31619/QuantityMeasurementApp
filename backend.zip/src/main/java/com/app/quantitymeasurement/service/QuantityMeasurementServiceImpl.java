package com.app.quantitymeasurement.service;

import com.app.quantitymeasurement.dto.OperationRequestDTO;
import com.app.quantitymeasurement.dto.QuantityDTO;
import com.app.quantitymeasurement.dto.QuantityOperationResultDTO;
import com.app.quantitymeasurement.entity.QuantityMeasurementEntity;
import com.app.quantitymeasurement.enums.OperationType;
import com.app.quantitymeasurement.exception.QuantityMeasurementException;
import com.app.quantitymeasurement.model.QuantityModel;
import com.app.quantitymeasurement.repository.IQuantityMeasurementRepository;
import com.app.quantitymeasurement.util.QuantityMathHelper;

import java.util.List;
import java.util.Locale;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.Authentication;

@Service
@RequiredArgsConstructor
public class QuantityMeasurementServiceImpl implements IQuantityMeasurementService {

    private final IQuantityMeasurementRepository repository;

    @Override
    @Transactional
    public QuantityOperationResultDTO convert(QuantityDTO source, String targetUnit) {
        QuantityDTO sanitizedSource = sanitizeQuantity(source, "Source quantity is required.");
        String resolvedTargetUnit = normalizeRequiredUnit(targetUnit, "Target unit is required.");

        try {
            validateUnitForType(resolvedTargetUnit, sanitizedSource.getMeasurementType());

            double resultValue = QuantityMathHelper.convert(
                    sanitizedSource.getValue(),
                    sanitizedSource.getUnitName(),
                    resolvedTargetUnit,
                    sanitizedSource.getMeasurementType());

            QuantityDTO resultQuantity = QuantityDTO.builder()
                    .value(resultValue)
                    .measurementType(sanitizedSource.getMeasurementType())
                    .unitName(resolvedTargetUnit)
                    .build();

            QuantityMeasurementEntity persisted = repository.save(
                    buildSuccessfulEntity(OperationType.CONVERT, sanitizedSource, null, resultQuantity, null));

            return toResultDTO(persisted);
        } catch (RuntimeException exception) {
            throw wrapAndRecordFailure(OperationType.CONVERT, sanitizedSource, null, exception);
        }
    }

    @Override
    @Transactional
    public QuantityOperationResultDTO compare(QuantityDTO firstQuantity, QuantityDTO secondQuantity) {
        QuantityDTO sanitizedFirst = sanitizeQuantity(firstQuantity, "First quantity is required.");
        QuantityDTO sanitizedSecond = sanitizeQuantity(secondQuantity, "Second quantity is required.");

        try {
            boolean comparisonResult = QuantityMathHelper.compare(
                    sanitizedFirst.getValue(),
                    sanitizedFirst.getUnitName(),
                    sanitizedFirst.getMeasurementType(),
                    sanitizedSecond.getValue(),
                    sanitizedSecond.getUnitName(),
                    sanitizedSecond.getMeasurementType());

            QuantityMeasurementEntity persisted = repository.save(
                    buildSuccessfulEntity(OperationType.COMPARE, sanitizedFirst, sanitizedSecond, null, comparisonResult));

            return toResultDTO(persisted);
        } catch (RuntimeException exception) {
            throw wrapAndRecordFailure(OperationType.COMPARE, sanitizedFirst, sanitizedSecond, exception);
        }
    }

    @Override
    @Transactional
    public QuantityOperationResultDTO add(QuantityDTO firstQuantity, QuantityDTO secondQuantity, String resultUnit) {
        return performArithmetic(OperationType.ADD, firstQuantity, secondQuantity, resultUnit);
    }

    @Override
    @Transactional
    public QuantityOperationResultDTO subtract(QuantityDTO firstQuantity, QuantityDTO secondQuantity, String resultUnit) {
        return performArithmetic(OperationType.SUBTRACT, firstQuantity, secondQuantity, resultUnit);
    }

    @Override
    @Transactional
    public QuantityOperationResultDTO multiply(QuantityDTO firstQuantity, QuantityDTO secondQuantity, String resultUnit) {
        return performArithmetic(OperationType.MULTIPLY, firstQuantity, secondQuantity, resultUnit);
    }

    @Override
    @Transactional
    public QuantityOperationResultDTO divide(QuantityDTO firstQuantity, QuantityDTO secondQuantity, String resultUnit) {
        return performArithmetic(OperationType.DIVIDE, firstQuantity, secondQuantity, resultUnit);
    }

    @Override
    @Transactional
    public QuantityOperationResultDTO operate(OperationRequestDTO request) {
        if (request == null) {
            throw new QuantityMeasurementException("Operation request is required.");
        }

        OperationType operationType = OperationType.from(request.getOperationType());

        switch (operationType) {
            case CONVERT:
                return convert(request.getFirstQuantity(), request.getTargetUnit());
            case COMPARE:
                return compare(request.getFirstQuantity(), request.getSecondQuantity());
            case ADD:
                return add(request.getFirstQuantity(), request.getSecondQuantity(), request.getTargetUnit());
            case SUBTRACT:
                return subtract(request.getFirstQuantity(), request.getSecondQuantity(), request.getTargetUnit());
            case MULTIPLY:
                return multiply(request.getFirstQuantity(), request.getSecondQuantity(), request.getTargetUnit());
            case DIVIDE:
                return divide(request.getFirstQuantity(), request.getSecondQuantity(), request.getTargetUnit());
            default:
                throw new QuantityMeasurementException("Unsupported operation: " + operationType);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<QuantityMeasurementEntity> getMeasurementHistory() {

        String email = getCurrentUserEmailSafe();

        if (email == null) {
            return List.of();
        }

        return repository.findByUserEmailOrderByCreatedAtDesc(email);
    }

    @Override
    @Transactional(readOnly = true)
    public List<QuantityMeasurementEntity> getMeasurementHistoryByOperation(String operationType) {

        String email = getCurrentUserEmailSafe();

        if (email == null) {
            return List.of();
        }

        String normalizedOperationType = normalizeRequiredValue(operationType, "Operation type is required.")
                .toUpperCase(Locale.ROOT);

        return repository.findByUserEmailAndOperationTypeOrderByCreatedAtDesc(
                email,
                normalizedOperationType
        );
    }

    private String getCurrentUserEmailSafe() {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();

            if (auth == null || !auth.isAuthenticated()) return null;

            Object principal = auth.getPrincipal();

            if (principal == null || principal.equals("anonymousUser")) return null;

            return principal.toString();

        } catch (Exception e) {
            return null;
        }
    }

    private QuantityOperationResultDTO performArithmetic(
            OperationType operationType,
            QuantityDTO firstQuantity,
            QuantityDTO secondQuantity,
            String resultUnit) {

        QuantityDTO sanitizedFirst = sanitizeQuantity(firstQuantity, "First quantity is required.");
        QuantityDTO sanitizedSecond = sanitizeQuantity(secondQuantity, "Second quantity is required.");

        String resolvedResultUnit = (resultUnit == null || resultUnit.trim().isEmpty())
                ? sanitizedFirst.getUnitName()
                : normalizeRequiredUnit(resultUnit, "Result unit is required.");

        try {
            validateUnitForType(resolvedResultUnit, sanitizedFirst.getMeasurementType());

            QuantityModel firstModel = toModel(sanitizedFirst);
            QuantityModel secondModel = toModel(sanitizedSecond);

            double resultValue;

            switch (operationType) {
                case ADD:
                    resultValue = QuantityMathHelper.add(
                            firstModel.getValue(), firstModel.getUnitName(), firstModel.getMeasurementType(),
                            secondModel.getValue(), secondModel.getUnitName(), secondModel.getMeasurementType());
                    break;
                case SUBTRACT:
                    resultValue = QuantityMathHelper.subtract(
                            firstModel.getValue(), firstModel.getUnitName(), firstModel.getMeasurementType(),
                            secondModel.getValue(), secondModel.getUnitName(), secondModel.getMeasurementType());
                    break;
                case MULTIPLY:
                    resultValue = QuantityMathHelper.multiply(
                            firstModel.getValue(), firstModel.getUnitName(), firstModel.getMeasurementType(),
                            secondModel.getValue(), secondModel.getUnitName(), secondModel.getMeasurementType());
                    break;
                case DIVIDE:
                    resultValue = QuantityMathHelper.divide(
                            firstModel.getValue(), firstModel.getUnitName(), firstModel.getMeasurementType(),
                            secondModel.getValue(), secondModel.getUnitName(), secondModel.getMeasurementType());
                    break;
                default:
                    throw new QuantityMeasurementException("Unsupported arithmetic operation: " + operationType);
            }

            double normalizedResultValue = QuantityMathHelper.convert(
                    resultValue,
                    firstModel.getUnitName(),
                    resolvedResultUnit,
                    firstModel.getMeasurementType());

            QuantityDTO resultQuantity = QuantityDTO.builder()
                    .value(normalizedResultValue)
                    .measurementType(firstModel.getMeasurementType())
                    .unitName(resolvedResultUnit)
                    .build();

            QuantityMeasurementEntity persisted = repository.save(
                    buildSuccessfulEntity(operationType, sanitizedFirst, sanitizedSecond, resultQuantity, null));

            return toResultDTO(persisted);

        } catch (RuntimeException exception) {
            throw wrapAndRecordFailure(operationType, sanitizedFirst, sanitizedSecond, exception);
        }
    }

    private QuantityDTO sanitizeQuantity(QuantityDTO quantity, String nullMessage) {
        if (quantity == null) {
            throw new QuantityMeasurementException(nullMessage);
        }

        if (quantity.getValue() == null) {
            throw new QuantityMeasurementException("Quantity value is required.");
        }

        String normalizedMeasurementType = normalizeMeasurementType(quantity.getMeasurementType());
        String normalizedUnit = normalizeRequiredUnit(quantity.getUnitName(), "Unit name is required");

        validateUnitForType(normalizedUnit, normalizedMeasurementType);

        return QuantityDTO.builder()
                .value(quantity.getValue())
                .measurementType(normalizedMeasurementType)
                .unitName(normalizedUnit)
                .build();
    }

    private void validateUnitForType(String unit, String measurementType) {
        if (!QuantityMathHelper.isValidUnitForMeasurementType(unit, measurementType)) {
            throw new QuantityMeasurementException(
                    "Unit '" + unit + "' is not valid for measurement type '" + measurementType + "'");
        }
    }

    private String normalizeMeasurementType(String measurementType) {
        String normalized = QuantityMathHelper.normalizeMeasurementType(
                normalizeRequiredValue(measurementType, "Measurement type is required"));

        if (normalized.equals("LengthUnit")) return "LENGTH";
        if (normalized.equals("WeightUnit")) return "WEIGHT";
        if (normalized.equals("VolumeUnit")) return "VOLUME";
        if (normalized.equals("TemperatureUnit")) return "TEMPERATURE";

        return normalized.toUpperCase(Locale.ROOT);
    }

    private String normalizeRequiredUnit(String unit, String message) {
        return normalizeRequiredValue(unit, message).toUpperCase(Locale.ROOT);
    }

    private String normalizeRequiredValue(String value, String message) {
        if (value == null || value.trim().isEmpty()) {
            throw new QuantityMeasurementException(message);
        }
        return value.trim();
    }

    private QuantityModel toModel(QuantityDTO quantity) {
        return QuantityModel.builder()
                .value(quantity.getValue())
                .measurementType(quantity.getMeasurementType())
                .unitName(quantity.getUnitName())
                .build();
    }

    private QuantityMeasurementEntity buildSuccessfulEntity(
            OperationType operationType,
            QuantityDTO first,
            QuantityDTO second,
            QuantityDTO result,
            Boolean comparisonResult) {

        QuantityMeasurementEntity entity = new QuantityMeasurementEntity();

        entity.setOperationType(operationType.name());
        setQuantity(entity, first, true);
        setQuantity(entity, second, false);
        setResultQuantity(entity, result);

        entity.setComparisonResult(comparisonResult);
        entity.setErrorMessage(null);
        entity.setSuccessful(true);
        entity.setUserEmail(getCurrentUserEmailSafe());

        return entity;
    }

    private QuantityMeasurementException wrapAndRecordFailure(
            OperationType operationType,
            QuantityDTO first,
            QuantityDTO second,
            RuntimeException exception) {

        String message = exception.getMessage() == null ? "Operation failed." : exception.getMessage();

        try {
            QuantityMeasurementEntity entity = new QuantityMeasurementEntity();

            entity.setOperationType(operationType.name());
            setQuantity(entity, first, true);
            setQuantity(entity, second, false);

            entity.setErrorMessage(message);
            entity.setSuccessful(false);
            entity.setUserEmail(getCurrentUserEmailSafe());

            repository.save(entity);

        } catch (Exception ignored) {}

        return new QuantityMeasurementException(message, exception);
    }

    private void setQuantity(QuantityMeasurementEntity entity, QuantityDTO quantity, boolean first) {
        if (quantity == null) return;

        if (first) {
            entity.setFirstOperandValue(quantity.getValue());
            entity.setFirstMeasurementType(quantity.getMeasurementType());
            entity.setFirstUnit(quantity.getUnitName());
        } else {
            entity.setSecondOperandValue(quantity.getValue());
            entity.setSecondMeasurementType(quantity.getMeasurementType());
            entity.setSecondUnit(quantity.getUnitName());
        }
    }

    private void setResultQuantity(QuantityMeasurementEntity entity, QuantityDTO result) {
        if (result == null) return;

        entity.setResultOperandValue(result.getValue());
        entity.setResultMeasurementType(result.getMeasurementType());
        entity.setResultUnit(result.getUnitName());
    }

    private QuantityOperationResultDTO toResultDTO(QuantityMeasurementEntity entity) {
        return QuantityOperationResultDTO.builder()
                .historyId(entity.getId())
                .operationType(entity.getOperationType())
                .successful(entity.getSuccessful())
                .firstQuantity(toQuantityDTO(entity.getFirstOperandValue(), entity.getFirstMeasurementType(), entity.getFirstUnit()))
                .secondQuantity(toQuantityDTO(entity.getSecondOperandValue(), entity.getSecondMeasurementType(), entity.getSecondUnit()))
                .resultQuantity(toQuantityDTO(entity.getResultOperandValue(), entity.getResultMeasurementType(), entity.getResultUnit()))
                .comparisonResult(entity.getComparisonResult())
                .errorMessage(entity.getErrorMessage())
                .createdAt(entity.getCreatedAt())
                .build();
    }

    private QuantityDTO toQuantityDTO(Double value, String measurementType, String unit) {
        if (value == null || measurementType == null || unit == null) return null;

        return QuantityDTO.builder()
                .value(value)
                .measurementType(measurementType)
                .unitName(unit)
                .build();
    }
}